<?php
include("../model/cadastroModel.php");
include("../bd/conexao.php");

Class Cadastro_Control{ 

public $dados;
public $conn;

function __construct(){
    $this->dados = new Cadastro_Model();
    $this->conn = new Conexao();            
}

function cadastrar($nome, $celular, $cpf, $rg, $email, $usuario, $senha, $datanasc){
    $this->dados->setNome($nome);
    $this->dados->setCelular($celular);
    $this->dados->setCpf($cpf);
    $this->dados->setRg($rg);
    $this->dados->setEmail($email);
    $this->dados->setUsuario($usuario);
    $this->dados->setSenha($senha);
    $this->dados->setDatanasc($datanasc);
    
    $sql = "INSERT INTO cadastro(nome, celular, cpf, rg, email, usuario, senha, datanasc)
     VALUES(:nome, :celular, :cpf, :rg, :email, :usuario, :senha, :datanasc)";

    $conexao = $this->conn->conect();
    try {
        $stmt = $conexao->prepare($sql);

        $stmt->bindValue(":nome", $this->dados->getNome());
        $stmt->bindValue(":celular", $this->dados->getCelular());
        $stmt->bindValue(":cpf", $this->dados->getCpf());
        $stmt->bindValue(":rg", $this->dados->getRg());
        $stmt->bindValue(":email", $this->dados->getEmail());
        $stmt->bindValue(":usuario", $this->dados->getUsuario());
        $stmt->bindValue(":senha", $this->dados->getSenha());
        $stmt->bindValue(":datanasc", $this->dados->getDatanasc());
        $stmt->execute();
    
    return true;
} catch (\Throwable $th) {
    return false;
        //throw $th;
    }
    }

    function selecionar(){
        $sql = "SELECT * FROM cadastro";
        $conexao = $this->conn->conect();
        $stmt = $conexao->prepare($sql);
        $stmt->execute();
        return $stmt;


    }
}
























?>