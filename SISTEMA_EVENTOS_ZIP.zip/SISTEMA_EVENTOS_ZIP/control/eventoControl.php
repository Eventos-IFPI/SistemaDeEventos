<?php
    include("../model/eventoModel.php");
    include("../bd/conexao.php");
  
  Class Evento_Control{  
    public $dados;
    public $conn;
    function __construct(){
        $this->dados = new Evento_Model();
        $this->conn = new Conexao();            
    }
    function View(){
        $sql = "SELECT * FROM Evento";
        $d = $this->conn->Conect();
        $dados=$d->prepare($sql);
        $dados->execute();
        return $dados;
      }
      function View_id($id_evento){
        $sql = "SELECT * FROM Evento where id_evento = :id_evento";
        $d = $this->conn->Conect();
        $dados = $d->prepare($sql);
        $dados->bindValue("id_evento", $id_evento);
        $dados->execute();
        return $dados;
    }
    function Add( $id_cadastro,$nome,$id_end,$data,$quantidade_pessoas,$tipoEvento){  
        $this->dados->setNome($nome);
        $this->dados->setData($data);
        $this->dados->setQuantidade_pessoas($quantidade_pessoas);
        $this->dados->setTipoEvento($tipoEvento);
        $this->dados->setId_end($id_end);
        $this->dados->setId_cadastro($id_cadastro);

        $sql = "INSERT INTO  Evento (id_cadastro,nome,id_end, data, quantidade_pessoas, tipoEvento) values (:id_cadastro,:nome,:id_end,:data,:quantidade_pessoas,:tipoEvento)";
        $d = $this->conn->Conect();
        $dados = $d->prepare($sql);
        $dados->bindValue(":id_cadastro", $this->dados->getId_cadastro());
        $dados->bindValue(":nome",$this->dados->getNome());
        $dados->bindValue(":id_end",$this->dados->getId_end());
        $dados->bindValue(":data",$this->dados->getData());
        $dados->bindValue(":quantidade_pessoas",$this->dados->getQuantidade_pessoas());
        $dados->bindValue(":tipoEvento",$this->dados->getTipoEvento());
        $dados->execute();     

        //header("Location: View.php");
    }
  }
?>
