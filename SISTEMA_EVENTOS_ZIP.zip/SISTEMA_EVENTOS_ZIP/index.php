<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Acesso ao site</title>
    <link rel="stylesheet"  href="CSS/estilo.css">

</head>
<body >
    
    <div style="width:420px; margin: 250px auto 0px auto;">
        <center><h1>Login</h1></center>
        <form action="processa.php" method="POST"></form>
            <input type="text" placeholder="Usuário">
            <input type="password" placeholder="Senha">
            <input type="submit" value="Entrar">
            <center><a href="view/cadastro.php">Ainda não é inscrito? Cadastre-se!</a></center>
            </form>
            <center><a href="view/paginaInicial.php" >teste</a></center>
    </div>

</body>
</html>