<?php

Class Cadastro_Model{
    public $id_cadastro;
    public $nome;
    public $celular;
    public $cpf;
    public $rg;
    public $email;
    public $usuario;
    public $senha;
    public $datanasc;

    function __construct(){
        $this->id_cadastro = 0;
    }

    function setNome($nome){
        $this->nome = $nome;
    }
    function getNome(){
        return $this->nome;
    }

    function setCelular($celular){
        $this->celular = $celular;
    }
    function getCelular(){
        return $this->celular;
    }

    function setCpf($cpf){
        $this->cpf = $cpf;
    }
    function getCpf(){
        return $this->cpf;
    }

    function setRg($rg){
        $this->rg = $rg;
    }
    function getRg(){
        return $this->rg;
    }

    function setEmail($email){
        $this->email = $email;
    }
    function getEmail(){
        return $this->email;
    }

    function setUsuario($usuario){
        $this->usuario = $usuario;
    }
    function getUsuario(){
        return $this->usuario;
    }

    function setSenha($senha){
        $this->senha = $senha;
    }
    function getSenha(){
        return $this->senha;
    }

    function setDatanasc($datanasc){
        $this->datanasc = $datanasc;
    }
    function getDatanasc(){
        return $this->datanasc;
    }

}
?>