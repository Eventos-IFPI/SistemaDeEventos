<?php

Class Endereco_Model{
    public $id_end;
    public $regiao;
    public $estado;
    public $cidade;
    public $bairro;
    public $rua;
    public $numero;

    function __construct(){
        $this->id_end = 0;
    }

    function setRegiao($regiao){
        $this->$this = regiao;
    }

    function getRegiao(){
        return $this->regiao;
    }

    function setEstado($estado){
        $this->$this = estado;
    }

    function getEstado(){
        return $this->estado;
    }

    function setCidade(){
        $this ->$this = cidade;
    }

    function getCidade(){
        return $this->cidade;
    }

    function setBairro($bairro){
        $this->$this = bairro;
    }

    function getBairro(){
        return $this->bairro;
    }

    function setRua($rua){
        $this->$this = rua;
    }

    function getRua(){
        return $this->rua;
    }

    function setNumero($numero){
        $this->$this = numero;
    }

    function getNumero(){
        return $this->numero;
    }

}
?>