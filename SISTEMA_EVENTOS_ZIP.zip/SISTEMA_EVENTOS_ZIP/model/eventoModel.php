<?php
Class Evento_Model{
    public $id_evento;
    public $id_cadastro;
    public $nome;
    public $id_end;
    public $data;
    public $quantidade_pessoas;
    public $tipoEvento;

    function __construct(){
        $this->id_evento = 0;
    }

    function setId_cadastro($id_cadastro){
        $this->$this = id_cadastro;
    }

    function getId_cadastro(){
        return $this->id_cadastro;
    }

    function setId_end($id_end){
        $this->$this = id_end;
    }

    function getId_end(){
        return $this->id_end;
    }

    function setNome($nome){
        $this->$this = nome;
    }

    function getNome(){
        return $this->nome;
    }

    function setData($data){
        $this->$this = data;
    }

    function getData(){
        return $this->data;
    }

    function setQuantidade_pessoas($quantidade_pessoas){
        $this->$this = quantidade_pessoas;
    }

    function getQuantidade_pessoas(){
        return $this->quantidade_pessoas;
    }

    function setTipoEvento($tipoEvento){
        $this->$this = tipoEvento;
    }

    function getTipoEvento(){
        return $this->tipoEvento;
    }
}
?>
