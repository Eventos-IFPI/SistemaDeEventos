<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Cadastro de evento</title>
    <link rel="stylesheet"  href="CSS/estilo.css">

</head>
<body >
    <?php echo "funcionando";
    ?>

    
</body>
</html>