<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Visualização do evento</title>
    <link rel="stylesheet"  href="CSS/estilo.css">

</head>
<body >
<?php echo "funcionando";
    ?>
    
</body>
</html>