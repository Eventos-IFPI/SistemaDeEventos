<?php 
/*error_reporting(E_ALL);
ini_set('display_errors', 1);*/

include("../control/cadastroControl.php");
$usuario = new Cadastro_Control();
    
if($_POST){
    
    if($usuario->cadastrar($_POST["nome"], $_POST["contato"], $_POST["cpf"], $_POST["rg"], $_POST["email"], $_POST["usuario"], $_POST["senha"], $_POST["data"])){
        echo('<script> alert("longin"); </script>');
        header("Location: ../index.php");
    }
    

}
?>
<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Cadastro</title>
    <link rel="stylesheet"  href="../CSS/estilo.css">
</head>
<body>
    <div id="corpo-form" style="width:420px; margin: 100px auto 0px auto; height:650px;">
        <center><h1>Cadastro</h1></center>
        <form action="#" method="POST">
            <input type="text" placeholder="Nome completo" name="nome" required>
            <input type="date" name="data" required placeholder="Data de Nascimento">
            <input type="email" placeholder="E-mail" name="email" required>
            <input type="text" placeholder="Contato"required onkeypress="return onlynumber();" maxlength="11" minlength="11" name="contato">
            <input type="text" placeholder="RG" required onkeypress="return onlynumber();" minlength="9" maxlength="9" name="rg">
            <input type="text" placeholder="CPF" required onkeypress="return onlynumber();" maxlength="11"minlength="11" name="cpf">
            <input type="text" placeholder="Usuário" required name="usuario">
            <input type="password" placeholder="Senha" required minlength="6" name="senha">
            <input type="password" placeholder="Confirmar senha" required minlength="6" name="senha2">
            <input type="submit" value="Cadastrar">
        </form>            
        </div>
        <script>
            function onlynumber(evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode( key );
                //var regex = /^[0-9.,]+$/;
                var regex = /^[0-9.]+$/;
                if( !regex.test(key) ) {
                    theEvent.returnValue = false;
                    if(theEvent.preventDefault) theEvent.preventDefault();
                }
            }
            function formata_mascara(campo_passado, mascara) {
                var campo = campo_passado.value.length;
                var saida = mascara.substring(0,1);
                var texto = mascara.substring(campo);
                if(texto.substring(0,1) != saida){
                    campo_passado.value += texto.substring(0,1);
                }
            }

        </script>
</body>
</html>
