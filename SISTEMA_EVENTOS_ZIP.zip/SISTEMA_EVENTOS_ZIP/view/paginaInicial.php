<?php
    /*$cadastrar = $_POST['cadastrarEventos.php'];
    $visualizar = $_POST['visualizarEventos.php'];*/
    
?>
<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Página inicial</title>
    <link rel="stylesheet"  href="../CSS/estilo.css">
</head>
<body>
    <div style="width:420px; margin: 250px auto 0px auto;">
        <form action="#" method="POST"></form>
            <input type="submit" name="cadastroEvento" value="Cadastrar Eventos">
            <input type="submit" name="visualizarEvento" value="Vizualizar Eventos">
            <center><a href="cadastrarEventos.php">teste Cadastrar Eventos</a></center>
            <center><a href="visualizarEventos.php">teste Vizualizar Eventos</a></center>
            </form>
    </div>
    
</body>
</html>
