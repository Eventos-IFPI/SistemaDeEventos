<?php
include("../control/cadastroControl.php");

$verificar = new Cadastro_Control();

if($_POST){
    $dados = $verificar->selecionar();
    $usuario = ($_POST['usuario']);
    $senha = ($_POST['senha']);

    foreach ($dados as $d){
        if ($usuario == $d['usuario'] && $senha == $d['senha']){
            header("Location: ./paginaInicial.php");
        }   
    }
    echo('<script> alert("ERRO! LOGIN NÃO ENCONTRADO"); </script>');
}


?>
<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Acesso ao site</title>
    <link rel="stylesheet"  href="../CSS/estilo.css">
</head>
<body >
    
    <div style="width:420px; margin: 250px auto 0px auto;">
        <center><h1>Login</h1></center>
        <form action="#" method="POST">
            <input type="text" name="usuario" placeholder="Usuário" required>
            <input type="password" name="senha"placeholder="Senha" minlength="1" required>
            <input type="submit" value="Entrar">
            <center><a href="cadastro.php">Ainda não é inscrito? Cadastre-se!</a></center>
            </form>
    </div>

</body>
</html>