<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Cadastro</title>
    <link rel="stylesheet"  href="CSS/estilo.css">
</head>
<body>
    <div id="corpo-form" style="width:420px; margin: 50px auto 0px auto; height:650px;">
        <center><h1>Cadrastro</h1></center>
        <form action="processa.php" method="POST"></form>
                <input type="text" placeholder="Nome completo">
                <input type="date" placeholder="Data de Nascimento">
                <input type="text" placeholder="E-mail">
                <input type="text" placeholder="Contato" onkeypress="return onlynumber();" maxlength="11" >
                <input type="text" placeholder="RG" onkeypress="return onlynumber();" maxlength="8">
                <input type="text" placeholder="CPF" onkeypress="return onlynumber();" maxlength="11">
                <input type="text" placeholder="Usuário">
                <input type="password" placeholder="Senha" minlength="6" >
                <input type="password" placeholder="Confirmar senha">
                <input type="submit" value="Cadastrar">
                <center><a href="paginaInicial.php" >teste</a></center>
        </div>
        <script>
            function onlynumber(evt) {
                var theEvent = evt || window.event;
                var key = theEvent.keyCode || theEvent.which;
                key = String.fromCharCode( key );
                //var regex = /^[0-9.,]+$/;
                var regex = /^[0-9.]+$/;
                if( !regex.test(key) ) {
                    theEvent.returnValue = false;
                    if(theEvent.preventDefault) theEvent.preventDefault();
                }
            }
            function formata_mascara(campo_passado, mascara) {
                var campo = campo_passado.value.length;
                var saida = mascara.substring(0,1);
                var texto = mascara.substring(campo);
                if(texto.substring(0,1) != saida){
                    campo_passado.value += texto.substring(0,1);
                }
            }

        </script>
</body>
</html>
