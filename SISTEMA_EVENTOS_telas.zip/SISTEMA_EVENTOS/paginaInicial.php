<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Página inicial</title>
    <link rel="stylesheet"  href="CSS/estilo.css">
</head>
<body>
    <div style="width:420px; margin: 250px auto 0px auto;">
        <form action="processa.php" method="POST"></form>
            <input type="submit" value="Cadastrar Eventos">
            <input type="submit" value="Vizualizar Eventos">
            <center><a href="cadastrarEventos.php">teste Cadastrar Eventos</a></center>
            <center><a href="visualizarEventos.php">teste Vizualizar Eventos</a></center>
            </form>
    </div>
    
</body>
</html>
