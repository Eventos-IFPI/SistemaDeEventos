<html lang="pt-br">
<head>
    <meta charset="utp-8"/>
    <title>Cadastro</title>
    <link rel="stylesheet"  href="CSS/estilo.css">
</head>
<body>
    <div id="corpo-form" style="width:420px; margin: 50px auto 0px auto; height:650px;">
        <center><h1>Cadrastro</h1></center>
        <form action="processa.php" method="POST"></form>
                <input type="text" placeholder="Nome completo">
                <input type="date" placeholder="Data de Nascimento">
                <input type="text" placeholder="E-mail">
                <input type="number" placeholder="Contato">
                <input type="number" placeholder="RG">
                <input type="number" placeholder="CPF">
                <input type="text" placeholder="Usuário">
                <input type="password" placeholder="Senha">
                <input type="password" placeholder="Confirmar senha">
                <input type="submit" value="Cadastrar">
                <center><a href="paginaInicial.php" >teste</a></center>
        </div>
</body>
</html>
